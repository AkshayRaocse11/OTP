<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\HappyNotes User\Desktop\OTPloging\otp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>