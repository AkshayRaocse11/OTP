<?php echo e($slot); ?>

<?php /**PATH C:\Users\HappyNotes User\Desktop\OTPloging\otp\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>