

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card ">
                    <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                    <div class="card-body">
                            Newly Registered Users
                       <div class="table-responsive">
                        <table class="table table-bordered" id="my_Table">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Role</th>
                                    <th scope="col">Mobile</th>
                                    <th scope="col">Location</th>
                                    <th scope="col">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $user_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($user->email != Auth::user()->email): ?>
                                <tr>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td><?php echo e($user->role); ?></td>
                                    <td><?php echo e($user->mobile_number); ?></td>
                                    <td><?php echo e($user->location); ?></td>
                                    <td>
                                      
                                       <?php echo e(\Carbon\Carbon::parse($user->created_at)->diffForHumans()); ?>

                                    </td>
                                </tr>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2">No records found.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="table-responsive mt-3">
                         Product Delievery Status
                        <table class="table table-bordered">
                            <thead class="thead-light">
                                <tr>
                                    <th scope="col">Product</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Delievery Status</th>
                                    <th scope="col">Order Placed Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $product_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($item->product); ?></td>
                                    <td>Rs.<?php echo e($item->price); ?></td>
                                    <td>
                                    
                                    <?php if($item->delievery_status=='Pending'): ?>
                                <button class="btn btn-sm btn-danger"><?php echo e($item->delievery_status); ?></button>                                        
                                    <?php else: ?>
                                    <button class="btn btn-sm btn-success"><?php echo e($item->delievery_status); ?></button>                                          
                                    <?php endif; ?>    
                                    
                                  
                                    </td>
                                    <td>
                                      
                                       <?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?>

                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="2">No records found.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
  <script>
  $(document).ready(function() {
    $('#my_Table').DataTable( {
        "order": [[ 6, "desc" ]]
    } );
} );    
      
  </script>  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HappyNotes User\Desktop\OTPloging\otp\resources\views/dashboard/index.blade.php ENDPATH**/ ?>